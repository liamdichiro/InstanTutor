// Fetching DOM elements for tutor center
const algebraT = document.querySelector("#algebraT");
const chemistryT = document.querySelector("#chemistryT");
const biologyT = document.querySelector("#biologyT");
const mechanicsT = document.querySelector("#mechanicsT");
const calculus_IT = document.querySelector("#calculus_IT");
const calculus_IIT = document.querySelector("#calculus_IIT");

// Initializing tutorCan
let tutorCan;

// Adding event listeners to each tutor element
algebraT.addEventListener("click", function () {
  tutorCan = "chemistry";
  window.location.href = "waitingtutor.html";
});

chemistryT.addEventListener("click", function () {
  tutorCan = "chemistry";
  window.location.href = "waitingtutor.html";
});

biologyT.addEventListener("click", function () {
  tutorCan = "biology";
  window.location.href = "waitingtutor.html";
});

mechanicsT.addEventListener("click", function () {
  tutorCan = "mechanics";
  window.location.href = "waitingtutor.html";
});

calculus_IT.addEventListener("click", function () {
  tutorCan = "calculus_I";
  window.location.href = "waitingtutor.html";
});

calculus_IIT.addEventListener("click", function () {
  tutorCan = "calculus_II";
  window.location.href = "waitingtutor.html";
});
