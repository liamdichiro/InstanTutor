// Fetching DOM elements for student center
const algebraS = document.querySelector("#algebraS");
const chemistryS = document.querySelector("#chemistryS");
const biologyS = document.querySelector("#biologyS");
const mechanicsS = document.querySelector("#mechanicsS");
const calculus_IS = document.querySelector("#calculus_IS");
const calculus_IIS = document.querySelector("#calculus_IIS");

// Initializing studentNeed
let studentNeed;

// Adding event listeners to each student element
algebraS.addEventListener("click", function () {
  studentNeed = "algebra";
  window.location.href = "waitingstudent.html";
});

chemistryS.addEventListener("click", function () {
  studentNeed = "chemistry";
  window.location.href = "waitingstudent.html";
});

biologyS.addEventListener("click", function () {
  studentNeed = "biology";
  window.location.href = "waitingstudent.html";
});

mechanicsS.addEventListener("click", function () {
  studentNeed = "mechanics";
  window.location.href = "waitingstudent.html";
});

calculus_IS.addEventListener("click", function () {
  studentNeed = "calculus_I";
  window.location.href = "waitingstudent.html";
});

calculus_IIS.addEventListener("click", function () {
  studentNeed = "calculus_II";
  window.location.href = "waitingstudent.html";
});
